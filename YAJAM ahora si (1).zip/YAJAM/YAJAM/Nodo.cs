﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YAJAM
{
    class Nodo
    {
        public int Dni { get; set; }
        public string Service { get; set; }
        public int Telefono { get; set; }
        public int Dias { get; set; }
        public Nodo siguiente { get; set; } //puntero 
        public Nodo anterior { get; set; } // puntero
        public Nodo(int dni, string service, int telefono, int dias) //contructor
        {
            this.Dni = dni;
            this.Service = service;
            this.Telefono = telefono;
            this.Dias = dias;
            siguiente = null;
            siguiente = null;
        }
        public override string ToString()
        {
            string prod = "Dni: " + Dni.ToString() + Environment.NewLine + "Servicio: " + Service.ToString() + Environment.NewLine + "Telefono: " + Telefono.ToString() + Environment.NewLine + "Dias: " + Dias.ToString() + Environment.NewLine;
            return prod;
        }
    }
}
