﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YAJAM
{
    class Stack_Empleado
    {
        public double dni { get; set; }
    }
}
