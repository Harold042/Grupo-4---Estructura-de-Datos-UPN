﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YAJAM
{
    public partial class Crear_Cuenta : Form
    {
        Queue<ColaEmpleado> administrado = new Queue<ColaEmpleado>();
        public Crear_Cuenta()
        {
            InitializeComponent();
        }
        void VerificarContra()
        {
            BtnCrearCuenta.Enabled = true;
            string contra, validar;
            contra = TxtContra.Text;
            validar = TxtValidar.Text;
            if (contra == validar)
            {
                BtnCrearCuenta.Enabled = true;
                errorProvider1.SetError(TxtContra, "");
                errorProvider1.SetError(TxtValidar, "");
            }
            else
            {
                BtnCrearCuenta.Enabled = false;
                errorProvider1.SetError(TxtContra, "Las contraseñas no son iguales");
                errorProvider1.SetError(TxtValidar, "Las contraseñas no son iguales");
            }
        }
        void Crear()
        {
            StreamReader sr;
            StreamWriter sw;
            string[] campos = new string[3];
            bool encontrado = false;
            string registro, nom, contra, user;
            try
            {
                sr = File.OpenText("Usuarios.txt");
                registro = sr.ReadLine();
                while (registro != null)
                {
                    campos = registro.Split(',');
                    user = TxtUser.Text;
                    if (campos[1] == user)
                    {
                        encontrado = true;
                        MessageBox.Show("El usuario ya existe, pruebe con otro", "Yajam", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        sr.Close();
                        break;
                    }
                    else
                    {
                        registro = sr.ReadLine();
                    }
                }
                if (encontrado == false)
                {
                    sr.Close();
                    sw = File.AppendText("Usuarios.txt");
                    nom = TxtNom.Text;
                    user = TxtUser.Text;
                    contra = TxtContra.Text;
                    sw.WriteLine(nom + ',' + user + ',' + contra);
                    MessageBox.Show("Cuenta creada correctamente","Yajam",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    sw.Close();
                }
            }
            catch (Exception E)
            {
                MessageBox.Show(E.Message);
            }
        }
        private void ControlNombre()
        {
            foreach (char caractér in TxtNom.Text)
            {
                if (char.IsDigit(caractér))
                {
                    errorProvider1.SetError(TxtNom, "El texto ingresado debe contener sólo letras");
                    BtnCrearCuenta.Enabled = false;
                }
                else
                {
                    errorProvider1.SetError(TxtNom, "");
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if ((TxtNom.Text == "") || (TxtContra.Text == "") || (TxtUser.Text == "") || (TxtValidar.Text == ""))
            {
                errorProvider1.SetError(TxtNom, "Completar los campos");
                errorProvider1.SetError(TxtUser, "Completar los campos");
                errorProvider1.SetError(TxtContra, "Completar los campos");
                errorProvider1.SetError(TxtValidar, "Completar los campos");
            }
            else
            {
                errorProvider1.SetError(TxtNom, "");
                errorProvider1.SetError(TxtUser, "");
                errorProvider1.SetError(TxtContra, "");
                errorProvider1.SetError(TxtValidar, "");
                Crear();
                ColaEmpleado emp = new ColaEmpleado();
                emp.Usuario = TxtUser.Text;
                emp.nombre = TxtNom.Text;
                administrado.Enqueue(emp);
                DGWsalida.DataSource = null;
                DGWsalida.DataSource = administrado.ToArray();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 I = new Form1();
            I.Visible = true;
            Visible = false;
        }

        private void TxtNom_TextChanged(object sender, EventArgs e)
        {
            BtnCrearCuenta.Enabled = true;
            ControlNombre();
        }

        private void TxtContra_TextChanged(object sender, EventArgs e)
        {
            VerificarContra();
        }

        private void TxtValidar_TextChanged(object sender, EventArgs e)
        {
            VerificarContra();
        }
    }
}
