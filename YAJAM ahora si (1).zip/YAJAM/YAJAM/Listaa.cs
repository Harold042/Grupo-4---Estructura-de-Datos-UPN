﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YAJAM
{
    class Listaa
    {
        Nodo ultimo, primero, encontrado, temp,actual;
        public Listaa()
        {
            primero = null;
        }

        public void agregar(Nodo pDato) //2 3 4
        {
            if (primero == null)
            {
                primero = pDato; // 2
                ultimo = pDato; // 2
            }
            else
            {
                pDato.anterior = ultimo; // 2 <-3 / 3 <-4
                ultimo.siguiente = pDato; // 2-> 3 / 3-> 4
                ultimo = pDato; // 3 / 4
            }
        }

        public Nodo buscar(int dni) // 2
        {
            temp = primero; // 1
            encontrado = null;
            while (encontrado == null && temp != null) // null, 1
                if (temp.Dni == dni) // 1==2 / 2==2
                    encontrado = temp;//x / 2
                else
                    temp = temp.siguiente;// 2
            return encontrado;// 2
        }

        public bool EliminarPrimero() // 
        {
            if (primero == null)
            {
                return false;
            }
            else
            {
                primero = primero.siguiente;
                primero.anterior = null;
                return true;
            }
        }

        public bool Eliminar(int dni)// 2
        {
            if (buscar(dni) != null)
            {
                if (encontrado == primero)
                    EliminarPrimero();
                else
                {
                    encontrado.anterior.siguiente = encontrado.siguiente;
                    if (encontrado.siguiente != null)
                        encontrado.siguiente.anterior = encontrado.anterior;
                    else
                        ultimo = encontrado.anterior;
                }
                return true;
            }
            else
                return false;
        }

        public bool EliminarUltimo()
        {
            if (ultimo == null)
                return false;
            else
            {
                ultimo = ultimo.anterior;
                ultimo.siguiente = null;
                return true;
            }
        }

        public string Mostrar()
        {
            string vProducto = "";
            temp = primero;
            while (temp != null)
            {
                vProducto += temp.ToString() + Environment.NewLine;
                temp = temp.siguiente;
            }
            return vProducto;
        }

        public void Modificar(int dni, string service, int telefono, int dias)
        {
            actual = primero;
            bool flasg = false;
            int nodobuscado = dni;
            while (actual != null && flasg == false)
            {
                if (actual.Dni == nodobuscado)
                {
                    actual.Dni = dni;
                    actual.Service = service;
                    actual.Telefono = telefono;
                    actual.Dias = dias;
                    MessageBox.Show("Cliente Modificado", "YAJAM", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    flasg = true;
                }
                actual = actual.siguiente;
            }
            if (flasg == false)
            {
                MessageBox.Show("Cliente no encontrado", "YAJAM", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
