﻿namespace YAJAM
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LBCrearCuenta = new System.Windows.Forms.LinkLabel();
            this.LBOlvidarContra = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnInicioDeSesion = new System.Windows.Forms.Button();
            this.TxtContra = new System.Windows.Forms.TextBox();
            this.TxtUsuario = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSalir = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // LBCrearCuenta
            // 
            this.LBCrearCuenta.AutoSize = true;
            this.LBCrearCuenta.BackColor = System.Drawing.Color.Transparent;
            this.LBCrearCuenta.Location = new System.Drawing.Point(33, 216);
            this.LBCrearCuenta.Name = "LBCrearCuenta";
            this.LBCrearCuenta.Size = new System.Drawing.Size(133, 24);
            this.LBCrearCuenta.TabIndex = 18;
            this.LBCrearCuenta.TabStop = true;
            this.LBCrearCuenta.Text = "Crear Cuenta";
            this.LBCrearCuenta.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LBCrearCuenta_LinkClicked);
            // 
            // LBOlvidarContra
            // 
            this.LBOlvidarContra.AutoSize = true;
            this.LBOlvidarContra.BackColor = System.Drawing.Color.Transparent;
            this.LBOlvidarContra.Location = new System.Drawing.Point(166, 216);
            this.LBOlvidarContra.Name = "LBOlvidarContra";
            this.LBOlvidarContra.Size = new System.Drawing.Size(229, 24);
            this.LBOlvidarContra.TabIndex = 17;
            this.LBOlvidarContra.TabStop = true;
            this.LBOlvidarContra.Text = "¿Olvidó su contraseña?";
            this.LBOlvidarContra.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LBOlvidarContra_LinkClicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14F, System.Drawing.FontStyle.Italic);
            this.label4.Location = new System.Drawing.Point(12, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(231, 28);
            this.label4.TabIndex = 16;
            this.label4.Text = "Ingrese sus datos :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))));
            this.label3.Location = new System.Drawing.Point(144, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(302, 34);
            this.label3.TabIndex = 15;
            this.label3.Text = "Bienvenido a Yajam";
            // 
            // BtnInicioDeSesion
            // 
            this.BtnInicioDeSesion.BackColor = System.Drawing.Color.Transparent;
            this.BtnInicioDeSesion.Location = new System.Drawing.Point(379, 114);
            this.BtnInicioDeSesion.Name = "BtnInicioDeSesion";
            this.BtnInicioDeSesion.Size = new System.Drawing.Size(120, 33);
            this.BtnInicioDeSesion.TabIndex = 14;
            this.BtnInicioDeSesion.Text = "Iniciar sesión";
            this.BtnInicioDeSesion.UseVisualStyleBackColor = false;
            this.BtnInicioDeSesion.Click += new System.EventHandler(this.BtnInicioDeSesion_Click);
            // 
            // TxtContra
            // 
            this.TxtContra.Location = new System.Drawing.Point(136, 163);
            this.TxtContra.Name = "TxtContra";
            this.TxtContra.PasswordChar = '*';
            this.TxtContra.Size = new System.Drawing.Size(216, 28);
            this.TxtContra.TabIndex = 13;
            // 
            // TxtUsuario
            // 
            this.TxtUsuario.Location = new System.Drawing.Point(136, 127);
            this.TxtUsuario.Name = "TxtUsuario";
            this.TxtUsuario.Size = new System.Drawing.Size(216, 28);
            this.TxtUsuario.TabIndex = 12;
            this.TxtUsuario.TextChanged += new System.EventHandler(this.TxtUsuario_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Italic);
            this.label2.Location = new System.Drawing.Point(13, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 23);
            this.label2.TabIndex = 11;
            this.label2.Text = "Contraseña:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Italic);
            this.label1.Location = new System.Drawing.Point(13, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "Usuario:";
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.Transparent;
            this.btnSalir.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(379, 163);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(120, 33);
            this.btnSalir.TabIndex = 19;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.button1_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.BackgroundImage = global::YAJAM.Properties.Resources.fondo_curva_azul_claro_53876_99565;
            this.ClientSize = new System.Drawing.Size(529, 277);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.LBCrearCuenta);
            this.Controls.Add(this.LBOlvidarContra);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.BtnInicioDeSesion);
            this.Controls.Add(this.TxtContra);
            this.Controls.Add(this.TxtUsuario);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Yajam";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel LBCrearCuenta;
        private System.Windows.Forms.LinkLabel LBOlvidarContra;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BtnInicioDeSesion;
        private System.Windows.Forms.TextBox TxtContra;
        private System.Windows.Forms.TextBox TxtUsuario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

