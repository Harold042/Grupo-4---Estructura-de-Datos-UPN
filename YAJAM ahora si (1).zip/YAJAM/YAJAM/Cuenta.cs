﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;      

namespace YAJAM
{
    public partial class Cuenta : Form
    {
        Stack<Stack_Empleado> Empleado = new Stack<Stack_Empleado>();
        Listaa yajam = new Listaa();
        string[] Servicio = { "HouseKeeping", "Comida", "Bebida", "Desayuno" , "Bar" , "Aire Condicionado" , "NONE" };
        public Cuenta()
        {
            InitializeComponent();
            timer1.Enabled = true;
        }

        private void ControlLista()
        {
            if ((TxtServicio.SelectedIndex >= 0))
            {
                errorProvider1.SetError(TxtServicio, "");
            }
            else
            {
                if ((TxtServicio.SelectedIndex <= -1))
                {
                    errorProvider1.SetError(TxtServicio, "Debe seleccionar un servicio");
                }
            }
        }

        void CargarServicio()
        {
            for (int i = 0; i < Servicio.Length; i++)
            {
                TxtServicio.Items.Add(Servicio[i]);
            }
        }

        void CargarServicioModificacion()
        {
            for (int i = 0; i < Servicio.Length; i++)
            {
                TxtModiServicio.Items.Add(Servicio[i]);
            }
        }

        public void LimpiaTXT()
        {
            txtDNI.Text = "";
            TxtServicio.Text = "";
            txtTelefono.Text = "";
            txtDias.Text = "";
            TxtModiDni.Text = "";
            TxtModiNumero.Text = "";
            TxtModiServicio.Text = "";
            TxtModiTele.Text = "";
            TxtEliminarDni.Text = "";
            TxtBuscar.Text = "";
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (txtTelefono.Text == "" || txtDNI.Text == "" || txtDias.Text == "" || TxtServicio.Text == "")
            {
                errorProvider1.SetError(txtDNI, "Complentar Campo");
                errorProvider1.SetError(TxtServicio, "Complentar Campo");
                errorProvider1.SetError(txtTelefono, "Complentar Campo");
                errorProvider1.SetError(txtDias, "Complentar Campo");

            }
            else
            {
                string vService = TxtServicio.SelectedItem.ToString();
                int VdNI = int.Parse(txtDNI.Text);
                int Vtelefono = int.Parse(txtTelefono.Text);
                int Vdias = int.Parse(txtDias.Text);
                if (yajam.buscar(VdNI) != null)
                {
                    MessageBox.Show("El Cliente ya Existe", "YAJAM",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                }
                else
                {
                    yajam.agregar(new Nodo(VdNI, vService, Vtelefono, Vdias));
                    LimpiaTXT();
                    txtDNI.Focus();
                    TxtSalida.Text = yajam.Mostrar();
                    errorProvider1.SetError(txtDNI, "");
                    errorProvider1.SetError(TxtServicio, "");
                    errorProvider1.SetError(txtTelefono, "");
                    errorProvider1.SetError(txtDias, "");
                }    
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (TxtEliminarDni.Text == "")
            {
                errorProvider1.SetError(TxtEliminarDni, "Complentar Campo");
            }
            else
            {
                Stack_Empleado dnis = new Stack_Empleado();
                dnis.dni = int.Parse(TxtEliminarDni.Text);
                Empleado.Push(dnis);
                DGVDni.DataSource = null;
                DGVDni.DataSource = Empleado.ToList();
                if (yajam.Eliminar(Convert.ToInt32(TxtEliminarDni.Text)))
                {
                    
                    MessageBox.Show("Cliente Eliminado", "YAJAM", MessageBoxButtons.OK,MessageBoxIcon.Information);
                    TxtSalida.Text = yajam.Mostrar();
                    errorProvider1.SetError(TxtEliminarDni, "");
                    LimpiaTXT();
                }
                else
                {
                    MessageBox.Show("El Cliente no Existe", "YAJAM",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }                
            }
            LimpiaTXT();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {

            if (TxtModiDni.Text == "" || TxtModiServicio.Text == "" || TxtModiNumero.Text == "" || TxtModiTele.Text == "")
            {
                errorProvider1.SetError(TxtModiDni, "Complentar Campo");
                errorProvider1.SetError(TxtModiServicio, "Complentar Campo");
                errorProvider1.SetError(TxtModiNumero, "Complentar Campo");
                errorProvider1.SetError(TxtModiTele, "Complentar Campo");
            }
            else
            {
                string vService = TxtModiServicio.SelectedItem.ToString();
                int VdNI = int.Parse(TxtModiDni.Text);
                int Vtelefono = int.Parse(TxtModiTele.Text);
                int Vdias = int.Parse(TxtModiNumero.Text);
                yajam.Modificar(VdNI, vService, Vtelefono, Vdias);
                TxtModiDni.Focus();
                TxtSalida.Text = yajam.Mostrar();
                LimpiaTXT();
                errorProvider1.SetError(TxtModiDni, "");
                errorProvider1.SetError(TxtModiServicio, "");
                errorProvider1.SetError(TxtModiNumero, "");
                errorProvider1.SetError(TxtModiTele, "");
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("¿Seguro que quiere Cerrar Sesión?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                Form1 f = new Form1();
                f.Visible = true;
                Visible = false;
            }
            
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (TxtBuscar.Text == "")
            {
                errorProvider1.SetError(TxtBuscar, "Complentar Campo");
            }
            else
            {
                if (yajam.buscar(Convert.ToInt32(TxtBuscar.Text)) == null)
                {
                    TxtBuscado.Text = "Cliente no Encontrado";
                    TxtBuscar.Text = "";
                }
                else
                {
                    TxtBuscado.Text = yajam.buscar(Convert.ToInt32(TxtBuscar.Text)).ToString();
                    TxtBuscar.Text = "";
                }
                errorProvider1.SetError(TxtBuscar, "");
                LimpiaTXT();

            }
            LimpiaTXT();
        }

        private void Cuenta_Load(object sender, EventArgs e)
        {
            CargarServicio();
            CargarServicioModificacion();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbDia.Text = DateTime.Now.ToLongDateString();
            lbHora.Text = DateTime.Now.ToShortTimeString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TxtBuscado.Clear();
        }
    }
}
