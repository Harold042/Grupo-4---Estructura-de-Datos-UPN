﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YAJAM
{
    class ColaEmpleado
    {
        public string nombre { get; set; }
        public string Usuario { get; set; }

    }
}
