﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YAJAM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void LBCrearCuenta_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Crear_Cuenta CC = new Crear_Cuenta();
            CC.Visible = true;
            Visible = false;
        }

        private void LBOlvidarContra_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Contraseña C = new Contraseña();
            C.Visible = true;
            Visible = false;
        }

        private void BtnInicioDeSesion_Click(object sender, EventArgs e)
        {
            if (TxtContra.Text == "")
            {
                errorProvider1.SetError(TxtContra, "Completar los campos");
            }
            else if (TxtUsuario.Text == "")
            {
                 errorProvider1.SetError(TxtUsuario, "Completar los campos");
            }
            else
            {
                string registro;
                string[] campos = new string[3];
                bool respuesta = false;
                StreamReader sr;
                try
                {
                    sr = File.OpenText("Usuarios.txt");
                    registro = sr.ReadLine();
                    while (registro != null)
                    {
                        campos = registro.Split(',');
                        if (campos[1] == TxtUsuario.Text && campos[2] == TxtContra.Text)
                        {
                            MessageBox.Show("Bienvenido " + campos[0],"Yajam",MessageBoxButtons.OK,MessageBoxIcon.Information);
                            respuesta = true;
                            Cuenta CD = new Cuenta();
                            CD.Visible = true;
                            Visible = false;
                            sr.Close();
                            break;
                        }
                        else
                        {
                            registro = sr.ReadLine();
                        }
                    }
                    if (respuesta == false)
                    {
                        sr.Close();
                        MessageBox.Show("Contraseña y/o usuario incorrecto","Yajam",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }

                }
                catch (Exception exp)
                {
                    MessageBox.Show(exp.Message);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("¿Seguro que quiere salir?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
                Application.Exit();
        }

        private void TxtUsuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
