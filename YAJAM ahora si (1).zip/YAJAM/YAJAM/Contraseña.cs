﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YAJAM
{
    public partial class Contraseña : Form
    {
        public Contraseña()
        {
            InitializeComponent();
        }
        void VerificarUsuario()
        {
            BtnProcesar.Enabled = true;
            StreamReader sr;
            string[] campos = new string[3];
            bool encontrado = false;
            string registro, user;
            try
            {
                sr = File.OpenText("Usuarios.txt");
                registro = sr.ReadLine();
                while (registro != null)
                {
                    campos = registro.Split(',');
                    user = TxtUser.Text;
                    if (campos[1] == user)
                    {
                        encontrado = true;
                        errorProvider1.SetError(TxtUser, "");
                        BtnProcesar.Enabled = true;
                        sr.Close();
                        break;
                    }
                    else
                    {
                        registro = sr.ReadLine();
                    }
                }
                if (encontrado == false)
                {
                    errorProvider1.SetError(TxtUser, "El usuario ingresado no existe");
                    BtnProcesar.Enabled = false;
                    sr.Close();
                }

            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        void VerificarContra()
        {
            BtnProcesar.Enabled = true;
            string contra, validar;
            contra = TxtContra.Text;
            validar = TxtValidar.Text;
            if (contra == validar)
            {
                BtnProcesar.Enabled = true;
                errorProvider1.SetError(TxtContra, "");
                errorProvider1.SetError(TxtValidar, "");
            }
            else
            {
                BtnProcesar.Enabled = false;
                errorProvider1.SetError(TxtContra, "Las contraseñas no son iguales");
                errorProvider1.SetError(TxtValidar, "Las contraseñas no son iguales");
            }
        }
        void ModifcarContra()
        {
            BtnProcesar.Enabled = true;
            StreamReader sr;
            StreamWriter sw;
            string[] campos = new string[3];
            string registro, user, contra;
            try
            {
                sr = File.OpenText("Usuarios.txt");
                sw = new StreamWriter("Auxiliar.txt");
                registro = sr.ReadLine();
                while (registro != null)
                {
                    campos = registro.Split(',');
                    user = TxtUser.Text;
                    contra = TxtContra.Text;
                    if (campos[1] == user)
                    {
                        BtnProcesar.Enabled = true;
                        sw.WriteLine(campos[0] + "," + campos[1] + "," + contra);

                    }
                    else
                    {
                        sw.WriteLine(campos[0] + "," + campos[1] + "," + campos[2]);
                    }
                    registro = sr.ReadLine();
                }
                sr.Close();
                sw.Close();
                File.Delete("Usuarios.txt");
                File.Move("Auxiliar.txt", "Usuarios.txt");
                MessageBox.Show("¡La contraseña fue cambiada correctamente!", "Yajam", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }
        private void BtnProcesar_Click(object sender, EventArgs e)
        {
            if ((TxtContra.Text == "") || (TxtUser.Text == "") || (TxtValidar.Text == ""))
            {
                errorProvider1.SetError(TxtUser, "Completar los campos");
                errorProvider1.SetError(TxtContra, "Completar los campos");
                errorProvider1.SetError(TxtValidar, "Completar los campos");
            }
            else
            {
                errorProvider1.SetError(TxtUser, "");
                errorProvider1.SetError(TxtContra, "");
                errorProvider1.SetError(TxtValidar, "");
                ModifcarContra();
            }
        }

        private void BtnVolver_Click(object sender, EventArgs e)
        {
            Form1 IS = new Form1();
            IS.Visible = true;
            Visible = false;
        }

        private void TxtUser_TextChanged(object sender, EventArgs e)
        {
            VerificarUsuario();
        }

        private void TxtContra_TextChanged(object sender, EventArgs e)
        {
            VerificarContra();
        }

        private void TxtValidar_TextChanged(object sender, EventArgs e)
        {
            VerificarContra();
        }
    }
}
